// ============================================================
// Server multiplayer — Coke Hangout (Nongkrong) Tetris
// ------------------------------------------------------------
// Model sesuai klarifikasi Grivy (Jul 2026): TIDAK real-time, dan Grivy
// TIDAK punya konsep "game session". GAME (server ini) yang mengelola sesi.
//
// Pengelompokan pemain = per KIOSK (device_id) + window bergulir:
//   - Pemain masuk kode di kiosk satu per satu (berurutan). Tiap pemain
//     yang join ke device_id yang sama dalam window 15 dtk = satu sesi game.
//   - Tiap pemain BARU join -> window dibuka lagi 15 dtk (rolling), maks 4.
//   - Window habis / slot penuh -> mulai. >1 pemain = multi, 1 = single.
//   - Setelah sesi sebuah kiosk mulai, join berikutnya ke kiosk itu -> sesi
//     BARU (kiosk dipakai berulang sepanjang hari).
//
// whats_app_session_id BUKAN kunci grup — itu identitas per-user (1:1 dgn
// user), hanya disimpan sebagai konteks. Server yang MEMBUAT session_id dan
// mengembalikannya saat join; klien memakai session_id itu untuk polling.
//
// Zero dependency: cukup `node server.js` (Node 18+). Store in-memory.
// ============================================================

'use strict';
const http = require('http');
const crypto = require('crypto');

const PORT        = parseInt(process.env.PORT || '8787', 10);
const WINDOW_MS   = parseInt(process.env.JOIN_WINDOW_SECONDS || '15', 10) * 1000;
const MAX_PLAYERS = parseInt(process.env.MAX_PLAYERS || '4', 10);
const GAME_MS     = parseInt(process.env.GAME_SECONDS || '180', 10) * 1000;
// grace setelah durasi game untuk menunggu skor pemain yang HP-nya lambat/tutup
const RESULT_GRACE_MS = parseInt(process.env.RESULT_GRACE_SECONDS || '25', 10) * 1000;
const CORS_ORIGIN = process.env.CORS_ORIGIN || '*';
// sesi dibersihkan dari memori sekian lama setelah selesai
const SESSION_TTL_MS = parseInt(process.env.SESSION_TTL_SECONDS || '300', 10) * 1000;
// endpoint API kiosk vendor untuk Game Start/End (dokumen Kiosk Vendor
// Feedback poin 4: wajib server-to-server, bukan fetch langsung dari browser
// pemain -- vendor menolak karena rawan skor palsu lewat devtools).
// Kosong = stub (cuma di-log), dipakai sebelum kredensial vendor tersedia.
const KIOSK_START_URL = process.env.KIOSK_START_URL || '';
const KIOSK_END_URL   = process.env.KIOSK_END_URL || '';
// Grivy Game Connect (API Game Vendor v4 �5) -- server-to-server, token sama
// dipakai utk voucher jadi tak boleh sampai ke klien. Kosong = stub (di-log).
const GRIVY_CONNECT_URL = process.env.GRIVY_CONNECT_URL || '';
const GRIVY_TOKEN       = process.env.GRIVY_TOKEN || '';

// ---------- store ----------
const sessions = new Map();       // session_id -> session
const deviceActive = new Map();   // device_key -> session_id sesi yang SEDANG membentuk/berjalan

const newId = () => crypto.randomBytes(6).toString('hex');
// kunci grup: device_id (kiosk). Tanpa kiosk (uji tanpa device) -> solo per user.
const deviceKeyOf = (deviceId, uid) => deviceId ? `dev:${deviceId}` : `u:${uid}`;

function createSession(deviceKey, durationSec) {
  const now = Date.now();
  const s = {
    id: newId(),
    device: deviceKey,
    phase: 'waiting',                 // waiting | playing | ended
    createdAt: now,
    durationMs: durationSec ? durationSec * 1000 : null,
    deadline: now + WINDOW_MS,        // batas window tunggu
    players: new Map(),               // user_id -> player
    roster: null,                     // array user_id (dibekukan saat mulai)
    mode: null,                       // single | multi
    playDeadline: null,               // batas kumpul skor
    endedAt: null,
  };
  sessions.set(s.id, s);
  deviceActive.set(deviceKey, s.id);  // jadi sesi "membentuk" untuk kiosk ini
  return s;
}

// Transisi fase dihitung lazily tiap request (tanpa timer per-sesi).
function advance(s) {
  const now = Date.now();
  if (s.phase === 'waiting' && now >= s.deadline) {
    s.phase = 'playing';
    s.roster = [...s.players.keys()];
    s.mode = s.roster.length > 1 ? 'multi' : 'single';
    const gameDuration = s.durationMs || GAME_MS;
    s.playDeadline = now + gameDuration + RESULT_GRACE_MS;
  }
  if (s.phase === 'playing') {
    const allIn = s.roster.length > 0 &&
      s.roster.every(uid => s.players.get(uid)?.submitted);
    if (allIn || now >= s.playDeadline) {
      s.phase = 'ended';
      s.endedAt = now;
    }
  }
}

// Snapshot yang aman dikirim ke klien.
function publicState(s) {
  const now = Date.now();
  const list = (s.phase === 'waiting' ? [...s.players.keys()] : s.roster || [])
    .map(uid => {
      const p = s.players.get(uid);
      return { user_id: uid, nickname: p ? p.nickname : 'Player' };
    });
  return {
    session_id: s.id,
    phase: s.phase,
    // saat waiting mode belum final (bisa berubah kalau ada yang join);
    // provisional dari jumlah pemain sekarang.
    mode: s.mode || (s.players.size > 1 ? 'multi' : 'single'),
    final_mode: s.mode,                       // null selama waiting
    count: list.length,
    max: MAX_PLAYERS,
    players: list,
    ms_left: s.phase === 'waiting' ? Math.max(0, s.deadline - now) : 0,
    window_ms: WINDOW_MS,
  };
}

function resultsPayload(s) {
  const isEnded = s.phase === 'ended';
  const rows = (s.roster || [...s.players.keys()])
    .map(uid => {
      const p = s.players.get(uid);
      return { user_id: uid, nickname: p.nickname,
               whats_app_session_id: p.whatsAppSessionId || '',
               score: p.score ?? 0,
               submitted: isEnded ? true : !!p.submitted };
    })
    .sort((a, b) => b.score - a.score);
  return { session_id: s.id, mode: s.mode, ready: isEnded, results: rows };
}

// ---------- HTTP ----------
function send(res, status, body) {
  const json = JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': CORS_ORIGIN,
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Cache-Control': 'no-store',
  });
  res.end(json);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', c => {
      data += c;
      if (data.length > 1e4) reject(new Error('payload too large')); // guard
    });
    req.on('end', () => {
      if (!data) return resolve({});
      try { resolve(JSON.parse(data)); } catch { reject(new Error('bad json')); }
    });
    req.on('error', reject);
  });
}

const clip = s => String(s || 'Player').slice(0, 40);

// Teruskan event ke API kiosk vendor server-to-server. Gagal/lambatnya vendor
// tidak boleh mem-block respons ke klien -- dicatat saja di log server.
async function relayToKiosk(urlStr, payload) {
  if (!urlStr) { console.log('[kiosk stub]', payload); return; }
  try {
    await fetch(urlStr, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
  } catch (err) {
    console.error('[kiosk] gagal memanggil API vendor:', err.message || err);
  }
}

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') return send(res, 204, {});

  const u = new URL(req.url, `http://${req.headers.host}`);
  const path = u.pathname.replace(/\/+$/, '') || '/';

  try {
    // --- health ---
    if (req.method === 'GET' && path === '/health') {
      return send(res, 200, { ok: true, sessions: sessions.size, uptime: process.uptime() });
    }

    // --- join: pemain masuk (dipanggil saat game di HP dibuka) ---
    // Grup per device_id (kiosk); server yang menentukan session_id.
    if (req.method === 'POST' && path === '/session/join') {
      const b = await readBody(req);
      // client (js/session.js) kirim user_uid/kiosk_id/nickname_entered
      // (skema baru, sama dgn server-php); user_id/device_id/nickname lama
      // tetap diterima sbg fallback (dipakai server/test.js).
      const uid = b.user_uid || b.user_id;
      if (!uid) return send(res, 400, { error: 'user_id wajib' });

      // API v4 §3: game_session_id kini dibuat kiosk, sama persis utk semua
      // pemain seronde -- kunci grup PASTI kalau ada, kosong -> cara lama.
      const key = b.game_session_id
        ? `gs:${b.game_session_id}`
        : deviceKeyOf(b.device_id || b.kiosk_id, uid);
      // ambil sesi yang sedang membentuk untuk kiosk ini
      let s = null;
      const activeId = deviceActive.get(key);
      if (activeId) { s = sessions.get(activeId); if (s) advance(s); }
      // tidak ada sesi waiting untuk kiosk ini (belum ada / yg lama sudah mulai)
      // -> buka sesi BARU (kiosk dipakai berurutan sepanjang hari)
      const durSec = b.duration ? parseInt(b.duration, 10) : null;
      if (!s || s.phase !== 'waiting') s = createSession(key, durSec);
      else if (!s.durationMs && durSec) s.durationMs = durSec * 1000;

      if (!s.players.has(uid) && s.players.size < MAX_PLAYERS) {
        s.players.set(uid, {
          user_id: uid,
          nickname: clip(b.nickname_entered || b.nickname),
          device_id: b.device_id || b.kiosk_id || '',
          whatsAppSessionId: b.wa_session_id || b.whats_app_session_id || '',
          score: null,
          submitted: false,
          joinedAt: Date.now(),
        });
        // rolling window: tiap pemain BARU join, buka lagi window penuh
        s.deadline = Date.now() + WINDOW_MS;
      } else if (s.players.has(uid)) {
        // re-join (reload HP): perbarui nickname; jangan gandakan / reset window
        s.players.get(uid).nickname = clip(b.nickname_entered || b.nickname || s.players.get(uid).nickname);
      }
      // slot penuh -> mulai sekarang (tidak menunggu sisa window)
      if (s.players.size >= MAX_PLAYERS) s.deadline = Date.now();
      advance(s);
      return send(res, 200, publicState(s));
    }

    // --- grivy game connect: registrasi "connected" server-to-server ---
    // Info lobi Grivy sendiri; tidak dipakai utk keputusan game apa pun di
    // sini, jadi gagal/kosong tidak boleh menghentikan game (selalu 200).
    if (req.method === 'POST' && path === '/grivy/connect') {
      const b = await readBody(req);
      if (!GRIVY_CONNECT_URL || !GRIVY_TOKEN) {
        console.log('[grivy stub]', b);
        return send(res, 200, { ok: false, error: 'grivy belum dikonfigurasi' });
      }
      try {
        const r = await fetch(GRIVY_CONNECT_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': GRIVY_TOKEN },
          body: JSON.stringify({ wa_session_id: b.wa_session_id || '', game_session_id: b.game_session_id || '' }),
        });
        return send(res, 200, { ok: r.ok, status: r.status, body: await r.json().catch(() => null) });
      } catch (err) {
        console.error('[grivy] gagal memanggil Game Connect:', err.message || err);
        return send(res, 200, { ok: false, error: err.message || 'request gagal' });
      }
    }

    // --- state: polling waiting room (pakai session_id dari /join) ---
    if (req.method === 'GET' && path === '/session/state') {
      const s = sessions.get(u.searchParams.get('session_id'));
      if (!s) return send(res, 404, { error: 'sesi tidak ditemukan' });
      advance(s);
      return send(res, 200, publicState(s));
    }

    // --- score: kirim skor akhir atau live sync ---
    if (req.method === 'POST' && path === '/session/score') {
      const b = await readBody(req);
      const s = sessions.get(b.session_id);
      if (!s) return send(res, 404, { error: 'sesi tidak ditemukan' });
      advance(s);
      const p = s.players.get(b.user_uid || b.user_id);
      if (!p) return send(res, 404, { error: 'pemain tidak ada di sesi' });

      const incomingScore = Math.max(0, parseInt(b.score, 10) || 0);
      if (b.live) {
        // live score sync selama bermain
        if (!p.submitted) {
          p.score = Math.max(p.score || 0, incomingScore);
        }
      } else {
        // final score submission (game over, time up, or exit beacon)
        p.score = Math.max(p.score || 0, incomingScore);
        p.submitted = true;
      }
      advance(s);
      return send(res, 200, { ok: true, ready: s.phase === 'ended' });
    }

    // --- results: polling ranking akhir ---
    if (req.method === 'GET' && path === '/session/results') {
      const s = sessions.get(u.searchParams.get('session_id'));
      if (!s) return send(res, 404, { error: 'sesi tidak ditemukan' });
      advance(s);
      return send(res, 200, resultsPayload(s));
    }

    // --- kiosk vendor: Game Start server-to-server (bukan dari browser
    // pemain -- syarat vendor, lihat KIOSK_START_URL di atas) ---
    if (req.method === 'POST' && path === '/kiosk/game-start') {
      const b = await readBody(req);
      await relayToKiosk(KIOSK_START_URL, {
        event: 'game_start',
        wa_session_id: b.wa_session_id || '',
        kiosk_id: b.kiosk_id || '',
        user_id: b.user_uid || b.user_id || '',
        nickname: clip(b.nickname_entered || b.nickname),
        session_id: b.session_id || '',
        timestamp: new Date().toISOString(),
      });
      return send(res, 200, { ok: true });
    }

    // --- kiosk vendor: Game End server-to-server. Kalau session_id dikenal
    // (sesi via /session/join), skor diambil dari catatan sesi KITA sendiri
    // -- bukan dari body request -- supaya klien tidak bisa mengarang skor
    // lewat devtools lalu kirim ke sini (inti alasan syarat server-to-server).
    // Tanpa sesi (mode lokal/single tanpa server) -> tidak ada yang bisa
    // divalidasi silang, pakai hasil dari klien apa adanya. ---
    if (req.method === 'POST' && path === '/kiosk/game-end') {
      const b = await readBody(req);
      let results = Array.isArray(b.results) ? b.results : [];
      const s = b.session_id && sessions.get(b.session_id);
      if (s) {
        advance(s);
        results = (s.roster || [...s.players.keys()])
          .map(uid => { const p = s.players.get(uid); return { nickname: p.nickname, score: p.score ?? 0 }; })
          .sort((pa, pb) => pb.score - pa.score);
      }
      await relayToKiosk(KIOSK_END_URL, {
        event: 'game_end',
        wa_session_id: b.wa_session_id || '',
        kiosk_id: b.kiosk_id || '',
        user_id: b.user_uid || b.user_id || '',
        nickname: clip(b.nickname_entered || b.nickname),
        session_id: b.session_id || '',
        completed: true,
        results,
        timestamp: new Date().toISOString(),
      });
      return send(res, 200, { ok: true });
    }

    return send(res, 404, { error: 'not found' });
  } catch (err) {
    return send(res, 400, { error: err.message || 'bad request' });
  }
});

// bersihkan sesi lama supaya memori tidak menumpuk (aktivasi jangka panjang)
setInterval(() => {
  const now = Date.now();
  for (const [id, s] of sessions) {
    const stale = (s.phase === 'ended' && s.endedAt && now - s.endedAt > SESSION_TTL_MS) ||
                  (now - s.createdAt > SESSION_TTL_MS + GAME_MS + WINDOW_MS);
    if (stale) {
      sessions.delete(id);
      if (deviceActive.get(s.device) === id) deviceActive.delete(s.device);
    }
  }
}, 60_000).unref();

server.listen(PORT, () => {
  console.log(`[mp] server jalan di :${PORT}  (window ${WINDOW_MS / 1000}s, max ${MAX_PLAYERS}, game ${GAME_MS / 1000}s)`);
});

module.exports = { server, sessions, deviceActive }; // untuk test
